package assn07;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Main {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Map<String,String> passwordManager = new PasswordManager<>();


        // your code below
        System.out.println("Enter Master Password");
        String enteredPassword = s.nextLine();

        while(!passwordManager.checkMasterPassword(enteredPassword)){
            System.out.println("Enter Master Password");
            enteredPassword = s.nextLine();
        }
        String enteredCommand = s.nextLine();
        while (!enteredCommand.equals("Exit")) {

            if (enteredCommand.equals("New password")) {
                String website = s.nextLine();
                String newPassword = s.nextLine();
                passwordManager.put(website, newPassword);
                System.out.println("New password added");
            }
            else if (enteredCommand.equals("Get password")) {
                String website = s.nextLine();

                if (passwordManager.get(website) == null){
                    System.out.println("Account does not exist");
                }
                else {
                    System.out.println(passwordManager.get(website));
                }
            }
            else if (enteredCommand.equals("Delete account")) {
                String website = s.nextLine();
                Set<String> set = passwordManager.keySet();
                boolean deleted = false;
                for (String str : set) {
                    if (str.equals(website)) {
                        passwordManager.remove(website);
                        System.out.println("Account deleted");
                        deleted = true;
                    }
                }
                if (!deleted) {
                    System.out.println("Account does not exist");
                }
            }
            else if (enteredCommand.equals("Check duplicate password")) {
                String password = s.nextLine();

                if (passwordManager.checkDuplicate(password).isEmpty()) {
                    System.out.println("No account uses that password");
                } else {
                    System.out.println("Websites using that password:");
                    List<String> websites = passwordManager.checkDuplicate(password);
                    for (String str : websites) {
                        System.out.println(str);
                    }
                }

            }
            else if (enteredCommand.equals("Get accounts")) {
                Set<String> set = passwordManager.keySet();
                System.out.println("Your accounts:");
                for (String str : set) {
                    System.out.println(str);
                }
            }
            else if (enteredCommand.equals("Generate random password")) {
                int length = s.nextInt();
                s.nextLine();
                System.out.println(passwordManager.generatesafeRandomPassword(length));
            }
            else {
                System.out.println("Command not found");
            }
            enteredCommand = s.nextLine();
        }


        // infinite loop to go back to "Enter master password"



        // loop to read and execute commands until "Exit" is entered




    }
}
