package assn07;

import java.util.*;

public class PasswordManager<K,V> implements Map<K,V> {
    private static final String MASTER_PASSWORD = "password321";
    private Account[] _passwords;

    public PasswordManager() {
        _passwords = new Account[50];
    }

    // TODO: put
    @Override
	public void put(K key, V value) {
		int index = Math.abs(key.hashCode() % _passwords.length); // hashcode value mod 50
		Account <K, V> newEntry = new Account<>(key, value);
		if (_passwords[index] == null) {
			_passwords[index] = newEntry;
		}
		else {
			Account<K, V> curr = _passwords[index];
			while (curr != null){
				if (curr.getWebsite().equals(key)) {
					curr.setPassword(value);
					return;
				}
				if (curr.getNext() == null) {
					curr.setNext(newEntry);
					return;
				}
				curr = curr.getNext();
			}
		}
	}
	@Override
	public Set<K> keySet() {
		Set<K> keys = new HashSet<>();
		for (int i = 0; i < _passwords.length; i++) {
			Account<K, V> curr = _passwords[i];
			while(curr != null) {
				keys.add(curr.getWebsite());
				curr = curr.getNext();
			}
		}

		return keys;
	}

	@Override
	public V get(K key) {
		int index = Math.abs(key.hashCode() % _passwords.length); // hashcode value mod 50
		Account<K,V> curr = _passwords[index];
		while (curr != null){
			if (curr.getWebsite().equals(key)){
				return curr.getPassword();
			}
			curr = curr.getNext();
		}

		return null;
	}
	@Override
	public V remove(K key) {
		int index = Math.abs(key.hashCode() % _passwords.length);
		if (_passwords[index] == null) {
			return null;
		}

		if (!_passwords[index].getWebsite().equals(key)) {
			Account <K,V> curr = _passwords[index];
			while (curr.getNext() != null){
				if (curr.getNext().getWebsite().equals(key)){
					V removedVal = (V) curr.getNext().getPassword();
					curr.setNext(curr.getNext().getNext());
					return removedVal;
				}
				curr = curr.getNext();

			}
		}

		else {
			V removedVal = (V) _passwords[index].getPassword();
			_passwords[index]=_passwords[index].getNext();
			return removedVal;
		}

		return null;
	}
	@Override
	public List<K> checkDuplicate(V value) {
		List <K> dupes = new ArrayList<>();
		for (int i = 0; i < _passwords.length; i++) {
			Account <K, V> curr = _passwords[i];
			while(curr != null) {
				if (curr.getPassword().equals(value)){
					dupes.add(curr.getWebsite());
				}
				curr = curr.getNext();
			}
		}

		return dupes;
	}
	@Override
	public int size() {
		int count = 0;
		for (int i = 0; i < _passwords.length; i++) {
			Account<K, V> curr = _passwords[i];
			while (curr != null) {
				count++;
				curr = curr.getNext();
			}
		}
		return count;
	}
    // TODO: checkMasterPassword
    @Override
    public boolean checkMasterPassword(String enteredPassword) {

        return MASTER_PASSWORD.equals(enteredPassword);
    }

    @Override
    public String generatesafeRandomPassword(int length) {

        if (length < 4) {
            length = 4;
        }

        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = length;
        Random random = new Random();

        // TODO: Ensure the minimum length is 4



        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }

    /*
    Used for testing, do not change
     */
    public Account[] getPasswords() {
        return _passwords;
    }

}




