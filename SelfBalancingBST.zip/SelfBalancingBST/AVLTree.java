package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Fields
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;

    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }
    
    private int updateHeight() {
    	if (isEmpty()) {
    		return -1;
    	}
    	
        if (getLeft().isEmpty() && getRight().isEmpty()) { // may need to replace with .equals()
            this._height = 0;
            return this.height();
        }

        int leftHeight = (!(getLeft().isEmpty()) ? _left.updateHeight() : -1);
        int rightHeight = (!(getRight().isEmpty()) ? _right.updateHeight() : -1);
        this._height = Math.max(leftHeight, rightHeight) + 1;
        return this.height();
    }

    private int updateSize() {
    	if (isEmpty()) {
    		return 0;
    	}
    	
        if (getLeft().isEmpty() && getRight().isEmpty()) {
            this._size = 1;
            return this.size();
        }

        int leftSize = (!(getLeft().isEmpty()) ? _left.updateSize() : 0);
        int rightSize = (!(getRight().isEmpty()) ? _right.updateSize() : 0);
        this._size = leftSize + rightSize + 1;
        return this.size();
    }


    /**
     * Rotates the tree left and returns
     * AVLTree root for rotated result.
     */
    private AVLTree<T> rotateLeft() {
        // You should implement left rotation and then use this
        // method as needed when fixing imbalances.

        // new root
        AVLTree<T> newRoot = this._right;
        
        // rotation
        this._right = newRoot._left;
        newRoot._left = this;
        newRoot.updateHeight();
        newRoot.updateSize();

        return newRoot;
    }

    /**
     * Rotates the tree right and returns
     * AVLTree root for rotated result.
     */
    private AVLTree<T> rotateRight() {
        // You should implement right rotation and then use this
        // method as needed when fixing imbalances.
        // TODO     
        
        AVLTree<T> newRoot = this._left;
        // rotation
        this._left = newRoot._right;
        newRoot._right = this;
        newRoot.updateHeight();
        newRoot.updateSize();

        return newRoot;
    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int height() {
        return _height;
    }

    @Override
    public int size() {
        return _size;
    }


    private AVLTree<T> balancedNode() {

        // -1 heights in empty nodes could be problem
        int balanceSkew = getLeft().height() - getRight().height();
        if (Math.abs(balanceSkew) > 1) {
            // check left-
            if (balanceSkew > 0) {
                int leftSkew = getLeft().getLeft().height() - getLeft().getRight().height(); // may cause issues
                if (leftSkew >= 0) {
                    // left left
                    return rotateRight();
                } else {
                    // left right
                    AVLTree<T> lchild = (AVLTree<T>) getLeft();
                    lchild = lchild.rotateLeft();
                    _left = lchild;
                    return rotateRight();
                }
                // check right-
            } else {
                int rightSkew = getRight().getRight().height() - getRight().getLeft().height(); // may cause issues
                if (rightSkew >= 0) {
                    // right right
                    return rotateLeft();
                } else {
                    // right left
                    AVLTree<T> rchild = (AVLTree<T>) getRight();
                    rchild = rchild.rotateRight();
                    _right = rchild;
                    return rotateLeft();
                }
            }
        } else {
            // balanced
            return this;
        }
    }

    @Override
    public SelfBalancingBST<T> insert(T element) {
        
        if (isEmpty()) {
            AVLTree<T> newNode = new AVLTree<>();
            newNode._value = element;
            newNode._left = new AVLTree<T>();
            newNode._right = new AVLTree<T>();
            newNode._height = 0;
            newNode._size = 1;
            return newNode;
        }
        
        if (element.compareTo(getValue()) < 0) {
            _left = (AVLTree<T>) getLeft().insert(element);
        } else if (element.compareTo(getValue()) > 0) {
            _right = (AVLTree<T>) getRight().insert(element);
        } else {
            return this;
        }
        
        this.updateSize();
        this.updateHeight();

        return balancedNode();
    }

    @Override
    public SelfBalancingBST<T> remove(T element) {

        if (isEmpty()) {
            return this;
        }

        int comparisonInt = element.compareTo(getValue());
        if (comparisonInt < 0) {
            _left = (AVLTree<T>) getLeft().remove(element);
        } else if (comparisonInt > 0) {
            _right = (AVLTree<T>) getRight().remove(element);
        } else { //node found
            // replace
            if (!(getLeft().isEmpty()) && !(getRight().isEmpty())) { //2 children
                T replacement = getRight().findMin();
                this._value = replacement;
                //remove replacement
                _right = (AVLTree<T>) getRight().remove(replacement);
            } else if (!(getLeft().isEmpty())) { //only left child
                // promote left
                return getLeft();
            } else if (!(getRight().isEmpty())) { //only right child
                // promote right
                return getRight();
            } else {
                // delete leaf
                return new AVLTree<T>();
            }
        }

        this.updateSize();
        this.updateHeight();

        return balancedNode();
    }

    @Override
    public T findMin() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
       
        if (getLeft().isEmpty()) {
            return getValue();
        }

        return getLeft().findMin();
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        
        if (getRight().isEmpty()) {
            return getValue();
        }

        return getRight().findMax();
    }

    @Override
    public boolean contains(T element) {
        if (isEmpty()) {
            return false;
        }
        T currVal = getValue();
        if (element.compareTo(currVal) == 0) {
            return true;
        } else if (element.compareTo(currVal) < 0) {
            return getLeft().contains(element);
        } else {
            return getRight().contains(element);
        }
    }

    @Override
    public boolean rangeContain(T start, T end) {
        if (isEmpty()) {
            return false;
        }

        T currVal = getValue();
        if (end.compareTo(currVal) < 0) {
            return getLeft().rangeContain(start, end);
        } else if (start.compareTo(currVal) > 0) {
            return getRight().rangeContain(start, end);
        } else {
            return true;
        }
    }

    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }
        return _right;
    }

}
