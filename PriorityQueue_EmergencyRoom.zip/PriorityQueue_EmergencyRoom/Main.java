package assn05;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        testP1();
        testP2();
        testP3();
        testP4();
    }

    // test Part 1
    public static void testP1(){

        SimpleEmergencyRoom room = new SimpleEmergencyRoom();
        room.addPatient(1, 4);
        room.addPatient(5, 3);
        room.addPatient(2, 10);
        room.addPatient(4, 30);
        room.addPatient(3, 1);


        System.out.println("Patients before dequeue:");
        List<Patient> patientsBefore = room.getPatients();
        System.out.println(patientsBefore.toString());

        room.dequeue();

        System.out.println("Patients after dequeue:");
        List<Patient> patientsAfter = room.getPatients();
        System.out.println(patientsAfter.toString());
        /*
        Part 1 - Write some tests to convince yourself that your code for Part 1 is working
         */
    }

    // test Part 2
    public static void testP2(){
        MaxBinHeapER heap = new MaxBinHeapER<>();

        heap.enqueue(1, 4);
        heap.enqueue(2, 3);
        heap.enqueue(3, 5);
        heap.enqueue(4, 2);


        System.out.println("Patients after enqueue:"); //Testing 2nd enqueue method
        Prioritized[] patientList = heap.getAsArray();
        for (int i = 0; i < patientList.length; i++) {
            System.out.println(patientList[i].toString());
        }

       /*
        Part 2 - Write some tests to convince yourself that your code for Part 2 is working
         */

        heap.dequeue();
        System.out.println("Patients after dequeue:"); //Testing 2nd enqueue method
        Prioritized[] patientdequeue = heap.getAsArray();
        for (int i = 0; i < patientdequeue.length; i++) {
            System.out.println(patientdequeue[i].toString());
        }


        heap.updatePriority(4, 1000);

        heap.enqueue("A");

        Prioritized[] patient2 = heap.getAsArray();
        for (int i = 0; i < patient2.length; i++) {
            System.out.println(patient2[i].toString());
        }


    }

    /*
    Part 3
     */
    public static void testP3(){

        System.out.println("---------------------HEAP BUILD TEST ----------------------");
        Patient[] patients = new Patient[]{

                new Patient<>("A", 3),
                new Patient<>("B", 1),
                new Patient<>("C", 5),
                new Patient<>("D", 2),
                new Patient<>("E", 4)

        };


        MaxBinHeapER transfer = new MaxBinHeapER(makePatients());
        Prioritized[] arr = transfer.getAsArray();
        for(int i = 0; i < transfer.size(); i++) {
            System.out.println("Value: " + arr[i].getValue()
                    + ", Priority: " + arr[i].getPriority());
        }


        transfer.dequeue();

        Prioritized[] arr2 = transfer.getAsArray();
        for(int i = 0; i < transfer.size(); i++) {
            System.out.println("Value: " + arr2[i].getValue()
                    + ", Priority: " + arr2[i].getPriority());
        }
    }

    /*
    Part 4
     */
    public static void testP4() {
                /*
        Part 4 - Write some tests to convince yourself that your code for Part 4 is working
         */

        compareRuntimes();

    }

    public static void fillER(MaxBinHeapER complexER) {
        for(int i = 0; i < 100000; i++) {
            complexER.enqueue(i);
        }
    }
    public static void fillER(SimpleEmergencyRoom simpleER) {
        for(int i = 0; i < 100000; i++) {
            simpleER.addPatient(i);
        }
    }

    public static Patient[] makePatients() {
        Patient[] patients = new Patient[10];
        for(int i = 0; i < 10; i++) {
            patients[i] = new Patient(i);
        }
        return patients;
    }

    public static double[] compareRuntimes() {
        // Array which you will populate as part of Part 4
        double[] results = new double[4];

        SimpleEmergencyRoom simpleER = new SimpleEmergencyRoom();
        fillER(simpleER);

        // Code for (Task 4.1) Here

        int simpleSize = simpleER.size();

        long simpleBefore = System.nanoTime();

        for (int i=0; i < simpleSize; i++){
            simpleER.dequeue();
        }

        long simpleAfter = System.nanoTime();

        results[0] = simpleAfter - simpleBefore;
        results[1] = results[0]/simpleSize;

        System.out.println("Inefficient method: time to dequeue all patients is:" + results[0] + " per patient: " + results[1]);


        MaxBinHeapER binHeap = new MaxBinHeapER();
        fillER(binHeap);

        // Code for (Task 4.2) Here

        int heapSize = binHeap.size();

        long heapBefore = System.nanoTime();

        for (int i=0; i < heapSize; i++){
            binHeap.dequeue();
        }

        long heapAfter = System.nanoTime();

        results[2] = heapAfter - heapBefore;
        results[3] = results[2]/heapSize;

        System.out.println("Efficient method: time to dequeue all patients is:" + results[2] + " per patient: " + results[3]);

        return results;
    }

}
