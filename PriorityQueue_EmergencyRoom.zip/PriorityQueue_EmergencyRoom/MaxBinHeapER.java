package assn05;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MaxBinHeapER  <V, P extends Comparable<P>> implements BinaryHeap<V, P> {

    private List<Prioritized<V,P>> _heap;

    /**
     * Constructor that creates an empty heap of hospital.Prioritized objects.
     */
    public MaxBinHeapER() {
        _heap = new ArrayList<>();
    }

    @Override
    public int size() {
        return _heap.size();
    }

    static int parentIndex(int index) {
        return ((index - 1)/2);
    }
    static int leftchildIndex(int index) {
        return (index*2 + 1);
    }
    static int rightchildIndex(int index) {
        return (index*2 + 2);
    }
    boolean validIndex(int index) {
        if ((index >= 0) && (index <= _heap.size() -1)) {
            return true;
        }
        else {
            return false;
        }
    }

    boolean hasleftchild(int index) {
        return (validIndex(leftchildIndex(index)));
    }

    boolean hasrightchild(int index) {
        return (validIndex(rightchildIndex(index)));
    }


    int bubbleUp(int index){

        while (index > 0 && _heap.get(parentIndex(index)).getPriority().compareTo(_heap.get(index).getPriority()) < 0) {
            int PIndex = parentIndex(index);
            Prioritized<V, P> parent = _heap.get(PIndex);
            Prioritized<V, P> child = _heap.get(index);
            _heap.set(PIndex, child);
            _heap.set(index, parent);
            index = PIndex;
        }
        return index;
    }
    int bubbleDown(int index){
        Prioritized <V, P> parent = _heap.get(index);

        if ( !hasleftchild(index) && !hasrightchild(index)) { //If the node is a leaf node (no children)
            return index;
        }
        else if (!hasleftchild(index)) { //if only has right child
            if (_heap.get(rightchildIndex(index)).getPriority().compareTo(_heap.get(index).getPriority()) > 0){ //if right child is larger than parent

                _heap.set(index, _heap.get(rightchildIndex(index))); //set the right child node to the index (parent index = child)
                _heap.set(rightchildIndex(index), parent); //set parent to right child index (child index = parent)
                index = rightchildIndex(index); //updates index to right child index
            }
            else {
                return index;
            }
        }
        else if (!hasrightchild(index)) { //only has left child (same as above but with left)
            if (_heap.get(leftchildIndex(index)).getPriority().compareTo(_heap.get(index).getPriority()) > 0){ //if left child is larger than parent

                _heap.set(index, _heap.get(leftchildIndex(index))); //set the right child node to the index (parent index = child)
                _heap.set(leftchildIndex(index), parent); //set parent to right child index (child index = parent)
                index = leftchildIndex(index); //updates index to right child index
            }
            else {
                return index;
            }

        }
        else if (_heap.get(leftchildIndex(index)).getPriority().compareTo(_heap.get(index).getPriority()) > 0 ||
                _heap.get(rightchildIndex(index)).getPriority().compareTo(_heap.get(index).getPriority()) > 0) {// if left or right child is bigger than parent
            int largerchildindex = 0; //defines largerchild index as zero (will be changed in next steps to either left or right child)
            if (_heap.get(rightchildIndex(index)).getPriority().compareTo(_heap.get(leftchildIndex(index)).getPriority()) >= 0) { //if right child >= left child
                largerchildindex = rightchildIndex(index);
            }
            else {
                largerchildindex = leftchildIndex(index);
            }

            _heap.set(index, _heap.get(largerchildindex)); //sets the larger child to its parent index
            _heap.set(largerchildindex, parent); //sets the parent to its child index
            index = largerchildindex;
            bubbleDown(index); //recursively calls function
        }

        return index;
    }

    // TODO (Task 2A): enqueue
    public void enqueue(V value) {
        Prioritized<V, P> patient = new Patient<>(value);
        _heap.add(patient);
        bubbleUp(_heap.size() - 1);
    }

    // TODO (Task 2A): enqueue
    @Override
    public void enqueue(V value, P priority) {
        Prioritized<V, P> patient = new Patient<>(value, priority);
        _heap.add(_heap.size(), patient);
        bubbleUp(_heap.size() - 1);
        System.out.println("Value: " + value + " Priority: " + priority + " patient code " + patient);
    }

    // TODO (Task 2A): dequeue
    @Override
    public V dequeue() {

        if (_heap.isEmpty()){
            return null;
        }
        else if (_heap.size() == 1){
            Prioritized<V, P> removedVal = _heap.get(0);
            _heap.remove(0);
            return removedVal.getValue();
        }
        else {
            Prioritized<V, P> removedVal = _heap.get(0);
            _heap.set(0, _heap.get(_heap.size() - 1));
            _heap.remove(_heap.size() - 1);
            bubbleDown(0);
            //System.out.println("Dequeueing Value " + removedVal.getValue() + ", heap is now size " + _heap.size());
            return (removedVal.getValue());
        }
    }


    // TODO (Task 2A): getMax
    @Override
    public V getMax() {
        if (_heap.isEmpty()) {
            return null;
        }
        else {
        Prioritized <V, P> max = _heap.get(0);
        return max.getValue(); }
    }

    // TODO (part 2B) : updatePriority
    public void updatePriority(V value, P newPriority) {
        int ind = -1;

        for (int i = 0; i < _heap.size(); i++) {
            if (_heap.get(i).getValue().equals(value)) {
                ind = i;              //searches value and retrieves index
            }
        }
        if (ind == -1) {
            System.out.println("Patient not found");
            return;
        }
        //sets the node to a new priority
        Prioritized <V,P> oldNode = _heap.get(ind);
        Prioritized<V, P> newNode = new Patient<>(value, newPriority);
       _heap.set(ind, newNode);

       //restore heap property
        if (newPriority.compareTo(oldNode.getPriority()) > 0) {
            bubbleUp(ind);
        }
        else {
            bubbleDown(ind);
        }
        for (int i = 0; i < _heap.size(); i++) {
            System.out.println("Index " + i + " value " + _heap.get(i).getValue() + " priority " + _heap.get(i).getPriority());
        }

    }

    /**
     * Constructor that builds a heap given an initial array of hospital.Prioritized objects.
     */
    // TODO (Task 3): overloaded constructor
    public MaxBinHeapER(Prioritized<V, P>[] initialEntries ) {
        _heap = new ArrayList<>();

        for (int i = 0; i < initialEntries.length; i++) {
            _heap.add(initialEntries[i]);
        }

        // Perform heap construction
        for (int i = parentIndex(_heap.size() - 1); i >= 0; i--) {
            bubbleDown(i);
        }
    }

    @Override
    public Prioritized<V, P>[] getAsArray() {
        Prioritized<V,P>[] result = (Prioritized<V, P>[]) Array.newInstance(Prioritized.class, size());
        return _heap.toArray(result);
    }

}
